<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\MemberModel;
use App\Models\AduanModel;
use App\Models\ResponsModel;

class Bpd extends BaseController
{
    protected $memberModel;

    public function __construct()
    {
        $this->memberModel = new MemberModel();
    }

    public function index()
    {
        $members = $this->memberModel
            ->select('tb_members.*, 
                        prov.nama as nama_provinsi, 
                        kota.nama as nama_kota, 
                        kec.nama as nama_kecamatan, 
                        desa.nama as nama_desa')
            ->join('tb_provinsi prov', 'prov.id_provinsi = tb_members.id_provinsi', 'left')
            ->join('tb_kota_kabupaten kota', 'kota.id_kota = tb_members.id_kota', 'left')
            ->join('tb_kecamatan kec', 'kec.id_kecamatan = tb_members.id_kecamatan', 'left')
            ->join('tb_desa_kelurahan desa', 'desa.id_desa = tb_members.id_desa', 'left')
            ->findAll();

        return view('admin/bpd/dashboard_view', ['members' => $members]);
    }

    // public function dashboard()
    // {

    // }

    public function verifikasiMember()
    {
        $members = $this->memberModel
            ->select('tb_members.*, 
                        prov.nama as nama_provinsi, 
                        kota.nama as nama_kota, 
                        kec.nama as nama_kecamatan, 
                        desa.nama as nama_desa')
            ->join('tb_provinsi prov', 'prov.id_provinsi = tb_members.id_provinsi', 'left')
            ->join('tb_kota_kabupaten kota', 'kota.id_kota = tb_members.id_kota', 'left')
            ->join('tb_kecamatan kec', 'kec.id_kecamatan = tb_members.id_kecamatan', 'left')
            ->join('tb_desa_kelurahan desa', 'desa.id_desa = tb_members.id_desa', 'left')
            ->findAll();

        return view('admin/bpd/verifikasi_member', ['members' => $members]);
    }

    public function listAduan()
    {
        $aduanModel = new AduanModel();
        $data['aduan'] = $aduanModel->orderBy('created_at', 'DESC')->findAll();

        return view('admin/bpd/aduan/list_aduan', $data);
    }

    public function kirimRespons($id_aduan)
    {
        $responsModel = new ResponsModel();
        $aduanModel = new AduanModel();

        // Handle file upload if exists
        $lampiranFile = $this->request->getFile('lampiran');
        $lampiranName = null;

        if ($lampiranFile && $lampiranFile->isValid() && !$lampiranFile->hasMoved()) {
            $lampiranName = $lampiranFile->getRandomName();
            $lampiranFile->move(FCPATH . 'uploads/lampiran', $lampiranName);
        }

        // Save to tb_respons
        $responsModel->save([
            'id_aduan' => $id_aduan,
            'judul' => $this->request->getPost('judul'),
            'isi' => $this->request->getPost('isi'),
            'lampiran' => $lampiranName
        ]);

        // Update aduan status
        $aduanModel->update($id_aduan, ['status' => 'Selesai']);

        return redirect()->back()->with('success', 'Aduan telah direspons');
    }

    // public function kirimAduan()
    // {
    //     $aduanModel = new AduanModel();

    //     $aduanModel->save([
    //         'judul' => $this->request->getPost('judul'),
    //         'isi'   => $this->request->getPost('isi'),
    //         'created_at' => date('Y-m-d H:i:s')
    //     ]);

    //     return redirect()->back()->with('success', 'Umpan balik berhasil dikirim.');
    // }
}
