<?php
$role = 'member';
include(APPPATH . 'Views/admin/layout/navbar_template.php');
?>
