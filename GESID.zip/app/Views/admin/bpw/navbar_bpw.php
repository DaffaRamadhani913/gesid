<?php
$role = 'bpw';
include(APPPATH . 'Views/admin/layout/navbar_template.php');
?>
