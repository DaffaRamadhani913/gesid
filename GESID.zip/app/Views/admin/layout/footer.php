<footer class="bg-dark text-white text-center py-3 mt-auto">
  <div class="container">
    &copy; 2025 GESID. All rights reserved.
  </div>
</footer>
