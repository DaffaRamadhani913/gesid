<?php
$role = 'superadmin';
include(APPPATH . 'Views/admin/layout/navbar_template.php');
?>
