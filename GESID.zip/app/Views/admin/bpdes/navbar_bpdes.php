<?php
$role = 'bpdes';
include(APPPATH . 'Views/admin/layout/navbar_template.php');
?>
