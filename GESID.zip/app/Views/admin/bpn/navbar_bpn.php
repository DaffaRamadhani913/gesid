<?php
$role = 'bpn';
include(APPPATH . 'Views/admin/layout/navbar_template.php');
?>
