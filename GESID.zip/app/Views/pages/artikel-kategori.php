<?= $this->extend('layout/template') ?>
<?= $this->section('content') ?>

<section class="py-5">
    <div class="container">
        <h2 class="fw-bold mb-4" data-aos="fade-up">
            Kategori: <?= $kategori_nama ?>
        </h2>
        <div class="row">
            <?php for ($i = 1; $i <= 4; $i++): ?>
                <?php $delay = $i * 100; // Delay bertahap per item 
                ?>
                <div class="col-md-3 mb-4" data-aos="zoom-in" data-aos-delay="<?= $delay ?>">
                    <div class="card h-100 shadow-sm border" style="background-color: #0d1b24; color: white;">
                        <img src="<?= base_url('assets/img/artikel/kategori-' . $kategori_id . '-' . $i . '.jpg') ?>"
                            class="card-img-top" alt="Artikel Kategori <?= $i ?>">
                        <div class="card-body">
                            <small class="d-block mb-2 text-light">
                                <i class="bi bi-calendar-event"></i> 8 Agustus 2025
                            </small>
                            <h6 class="fw-bold text-white">Acara Desa <?= $kategori_id == 1 ? 'Budaya' : 'Kegiatan' ?> <?= $i ?></h6>
                            <a href="<?= base_url('artikel/kategori/' . $kategori_id . '/detail/' . $i) ?>"
                                class="btn btn-warning btn-sm mt-2">Baca</a>
                        </div>
                    </div>
                </div>
            <?php endfor; ?>
        </div>
    </div>
</section>

<?= $this->endSection() ?>