<?= $this->extend('layout/template') ?>
<?= $this->section('content') ?>

<section class="py-5">
    <div class="container">
        <h1 class="fw-bold" style="color: white;" data-aos="fade-up">
            Generasi Emas Indonesia (GESID)
        </h1>
        <p class="mb-4" style="color: white;" data-aos="fade-up" data-aos-delay="100">
            <i class="bi bi-calendar-event"></i> 2025 | Organisasi GESID
        </p>

        <img src="<?= base_url($artikel['gambar']) ?>"
            alt="Logo GESID"
            class="img-fluid shadow rounded me-3 mb-3"
            style="max-width: 350px; float: left;"
            data-aos="zoom-in" data-aos-delay="200">

        <p style="font-size: 1.1rem; line-height: 1.6; text-align: justify;"
            data-aos="fade-up" data-aos-delay="300">
            <strong>Generasi Emas Indonesia (GESID)</strong> adalah organisasi yang dibentuk pada tahun 2023
            dengan fokus utama pada pengembangan desa dalam menghadapi era globalisasi dan tantangan lingkungan.
            GESID memandang desa sebagai elemen penting dalam mendorong pembangunan berkelanjutan
            melalui pengelolaan sumber daya alam, peningkatan ketahanan pangan, dan adaptasi terhadap perubahan iklim.
        </p>

        <p style="font-size: 1.1rem; line-height: 1.6; text-align: justify;"
            data-aos="fade-up" data-aos-delay="400">
            Pembentukan GESID didorong oleh dua faktor utama.
            Pertama, <em>peran desa dalam pembangunan berkelanjutan</em> sangatlah vital.
            Desa memiliki potensi besar dalam mendukung pembangunan yang berkelanjutan,
            baik dari sisi sumber daya alam maupun kualitas sumber daya manusia.
            Desa yang kuat dan mandiri diyakini mampu mendorong kesejahteraan secara menyeluruh
            serta menciptakan kemandirian ekonomi.
        </p>

        <p style="font-size: 1.1rem; line-height: 1.6; text-align: justify;"
            data-aos="fade-up" data-aos-delay="500">
            Kedua, adanya <em>bonus demografi 2020–2045</em>.
            Indonesia diperkirakan akan mengalami periode di mana jumlah penduduk usia produktif
            jauh lebih besar dibandingkan usia non-produktif.
            Kondisi ini juga akan dirasakan di wilayah pedesaan,
            sehingga pemberdayaan generasi muda desa menjadi sangat penting
            untuk memaksimalkan potensi.
        </p>

        <p style="font-size: 1.1rem; line-height: 1.6; text-align: justify;"
            data-aos="fade-up" data-aos-delay="600">
            Melalui program pelatihan, pendampingan, dan kolaborasi lintas sektor,
            GESID berkomitmen untuk membangun kapasitas masyarakat desa agar mampu beradaptasi dengan perkembangan zaman,
            memanfaatkan teknologi tepat guna, dan menjaga kelestarian lingkungan.
            Harapannya, desa-desa di Indonesia tidak hanya menjadi pusat produksi pangan,
            tetapi juga pusat inovasi dan ketahanan sosial di tengah perubahan global.
        </p>

        <div style="clear: both;"></div>

        <a href="<?= base_url('artikel') ?>"
            class="btn btn-outline-secondary mt-4"
            data-aos="fade-up" data-aos-delay="700">
            ← Kembali ke Semua Artikel
        </a>
    </div>
</section>

<?= $this->endSection() ?>