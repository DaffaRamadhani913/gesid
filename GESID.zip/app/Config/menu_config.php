<?php
return [
  'bpn' => [
    ['url' => 'admin/bpn', 'icon' => 'mdi:view-dashboard-outline', 'label' => 'Dashboard'],
    ['url' => 'admin/bpn/aduan', 'icon' => 'mdi:alert-outline', 'label' => 'Aduan'],
    ['url' => 'admin/bpn/verifikasi-member', 'icon' => 'mdi:account-check-outline', 'label' => 'Verifikasi Member'],
    ['url' => 'admin//bpn/adminbpw', 'icon' => 'mdi:account-tie-outline', 'label' => 'Admin BPW'],
  ],
  'bpd' => [
    ['url' => 'admin/bpd', 'icon' => 'mdi:view-dashboard-outline', 'label' => 'Dashboard'],
    ['url' => 'admin/bpd/aduan', 'icon' => 'mdi:alert-outline', 'label' => 'Aduan'],
    ['url' => 'admin/bpd/verifikasi-member', 'icon' => 'mdi:account-check-outline', 'label' => 'Verifikasi Member'],
],

 'bpdes' => [
    ['url' => 'admin/bpdes', 'icon' => 'mdi:view-dashboard-outline', 'label' => 'Dashboard'],
    ['url' => 'admin/bpdes/aduan', 'icon' => 'mdi:alert-outline', 'label' => 'Aduan'],
    ['url' => 'admin/bpdes/verifikasi-member', 'icon' => 'mdi:account-check-outline', 'label' => 'Verifikasi Member'],
],


  'bpw' => [
  ['url' => 'admin/bpw', 'icon' => 'mdi:view-dashboard-outline', 'label' => 'Dashboard'],
  ['url' => 'admin/bpw/aduan', 'icon' => 'mdi:alert-outline', 'label' => 'Aduan'],
  ['url' => 'admin/bpw/verifikasi-member', 'icon' => 'mdi:account-check-outline', 'label' => 'Verifikasi Member'],
  ['url' => 'admin//bpw/adminbpd', 'icon' => 'mdi:account-tie-outline', 'label' => 'Admin BPD'],
],
  'superadmin' => [
    ['url' => 'admin/superadmin', 'icon' => 'mdi:view-dashboard-outline', 'label' => 'Dashboard'],
    ['url' => 'admin/superadmin/members/list_view', 'icon' => 'mdi:account-group', 'label' => 'Data Member'],
    ['url' => 'admin/superadmin/pengurus/manage_view', 'icon' => 'mdi:account-tie', 'label' => 'Pengurus BPN'],
    ['url' => 'admin/superadmin/roles/access_control', 'icon' => 'mdi:shield-account-outline', 'label' => 'Hak Akses'],

    // ✅ Tambahan Menu Baru
    ['url' => 'admin/slider', 'icon' => 'mdi:image-album', 'label' => 'Kelola Slider'],
    ['url' => 'admin/selayang-pandang', 'icon' => 'mdi:book-open-outline', 'label' => 'Selayang Pandang'],
    ['url' => 'admin/visi-misi', 'icon' => 'mdi:target-variant', 'label' => 'Visi & Misi'],
    ['url' => 'admin/superadmin/adminbpn', 'icon' => 'mdi:account-tie-outline', 'label' => 'Admin BPN'],
    // ✅ Tambahan menu Event
    ['url' => 'admin/events', 'icon' => 'mdi:calendar-star', 'label' => 'Event'],
  ],
  'member' => [
    ['url' => 'member', 'icon' => 'mdi:view-dashboard-outline', 'label' => 'Dashboard'],
    ['url' => 'member/aduan', 'icon' => 'mdi:alert-outline', 'label' => 'Aduan'],
    ['url' => 'member/profile', 'icon' => 'mdi:account-circle-outline', 'label' => 'Profil Saya'],
  ],


];
